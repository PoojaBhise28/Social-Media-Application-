package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    DatabaseUtil dbUtil;
    EditText name, email,contact, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

    }

    public void user_register(View view){

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        contact = findViewById(R.id.contact);
        password = findViewById(R.id.password);

        dbUtil = new DatabaseUtil(this);
        Boolean isRegistered = dbUtil.insert_user_data(name.getText().toString(), contact.getText().toString(), email.getText().toString(), password.getText().toString());
        if(isRegistered){
            Toast.makeText(this, "success!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
        }else{
            Toast.makeText(this, "something went wrong", Toast.LENGTH_SHORT).show();

        }

    }
}