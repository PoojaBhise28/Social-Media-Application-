package com.example.test;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    String user_email, user_name, user_contact;
    byte[] user_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
//        mAppBarConfiguration = new AppBarConfiguration.Builder(
//                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
//                .setDrawerLayout(drawer)
//                .build();
        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.nav_home)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        System.out.println("navController:::"+ navController);

        Bundle getExtras = getIntent().getExtras();
        Toast.makeText(this, getExtras.getString("user_name"), Toast.LENGTH_LONG).show();

        user_email = getExtras.getString("user_email");
        user_name = getExtras.getString("user_name");
        user_contact = getExtras.getString("user_contact");
//        user_image = getExtras.getByteArray("user_image");

        System.out.println(user_email+"  "+ user_name+"===="+user_image);


//Display email on slidebar
//        View myLayout = getLayoutInflater().inflate(R.layout.nav_header_main, null);
//        TextView tv = myLayout.findViewById(R.id.textView);
//        tv.setText(user_email);
//        TextView user_email_text = (TextView) findViewById(R.id.text);
//        System.out.println(user_email_text);

//        user_email_text.setText(user_email.toString());
        SharedPreferences sp = getSharedPreferences("login", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putBoolean("islogin", true);
        edit.putString("name", user_name);
        edit.putString("email", user_email);
        edit.putString("contact", user_contact);
//        edit.putString("contact", user_contact);


        edit.commit();

        setImageView(navigationView);

    }

    public void setImageView( NavigationView navigationView){
        View headerView = navigationView.getHeaderView(0);
        ImageView btn = (ImageView)headerView.findViewById(R.id.imageView);

        Bitmap bitmap;
        DatabaseUtil dbUtil= new DatabaseUtil(this);
        HashMap<String,Object> user_data = dbUtil.get_user_profile_pic(user_email);
        System.out.println("user_data:::"+ user_data.get("user_data"));

        System.out.println("viewwww:::"+btn);
        if(user_data.get("user_data") == null){
            Toast.makeText(this, "Invalid", Toast.LENGTH_LONG).show();
            return ;
        }
        else{
            GetterSetterUserProfile userprofile = (GetterSetterUserProfile) user_data.get("user_data");
            System.out.println("userprofile::::"+ userprofile.getImage());
            if(userprofile.getImage()!=null){
                byte[] user_image = userprofile.getImage();
                System.out.println(user_image+"  user_image");
                System.out.println("imageeeeee");
                Bitmap b1 = BitmapFactory.decodeByteArray(user_image, 0, user_image.length);
//                ImageView btn = (ImageView)findViewById(R.id.imageView);
                btn.setImageBitmap(b1);
            }




        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }


    public void view_profile(View view){
        System.out.println("image clicked");
        Intent intent = new Intent(this, UserProfile.class);
        intent.putExtra("user_name", user_name);
        intent.putExtra("user_email", user_email);
        intent.putExtra("user_contact", user_contact);
        startActivity(intent);
        

    }

    public void select_template(View view){
        System.out.println("select template clicked");
        Intent intent = new Intent(this, CaptureImage.class);
        intent.putExtra("user_name", user_name);
        intent.putExtra("user_email", user_email);
        intent.putExtra("user_contact", user_contact);
        startActivity(intent);
    }

    @Override
    public void onBackPressed(){

    }
}