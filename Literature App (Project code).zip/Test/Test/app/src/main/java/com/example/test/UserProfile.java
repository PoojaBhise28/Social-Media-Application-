package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

public class UserProfile extends AppCompatActivity {
    TextView user_name, user_email, user_contact;
    public static final int PICK_IMAGE = 1;
    private Bitmap bitmap;
    DatabaseUtil dbUtil;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE) {
            //TODO: action
            System.out.println("image selected"+ data.getData());
            ImageView btn = (ImageView)findViewById(R.id.user_img);
//            btn.setImageResource(R.drawable.profile);
            try {
                // We need to recyle unused bitmaps
                if (bitmap != null) {
                    bitmap.recycle();
                }
                InputStream stream = getContentResolver().openInputStream(
                        data.getData());
                bitmap = BitmapFactory.decodeStream(stream);
                stream.close();
                btn.setImageBitmap(bitmap);
                dbUtil = new DatabaseUtil(this);

                Boolean isRegistered = dbUtil.update_profile(bitmap, user_email.getText().toString());
//                if(isRegistered){
//                    Toast.makeText(this, "success!", Toast.LENGTH_SHORT).show();
//                    Intent intent = new Intent(this, Login.class);
//                    startActivity(intent);
//                }else{
//                    Toast.makeText(this, "something went wrong", Toast.LENGTH_SHORT).show();
//
//                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        Bundle extras = getIntent().getExtras();
        user_name = (TextView) findViewById(R.id.name);
        user_email = (TextView) findViewById(R.id.email);
        user_contact = (TextView) findViewById(R.id.contact);


        ImageView btn = (ImageView)findViewById(R.id.user_img);
        btn.setImageResource(R.drawable.profile);


        user_name.setText(extras.getString("user_name"));
        user_email.setText(extras.getString("user_email"));
        user_contact.setText(extras.getString("user_contact"));

        dbUtil = new DatabaseUtil(this);

        HashMap<String,Object> user_data = dbUtil.get_user_profile_pic(extras.getString("user_email"));
        System.out.println("user_data:::"+ user_data.get("user_data"));

        if(user_data.get("user_data") == null){
            Toast.makeText(this, "Invalid", Toast.LENGTH_LONG).show();
            return ;
        }
        else{
            GetterSetterUserProfile userprofile = (GetterSetterUserProfile) user_data.get("user_data");
            System.out.println("userprofile::::"+ userprofile.getImage());
            if(userprofile.getImage()!=null){
                byte[] user_image = userprofile.getImage();
                System.out.println(user_image+"  user_image");
                System.out.println("imageeeeee");
                Bitmap b1 = BitmapFactory.decodeByteArray(user_image, 0, user_image.length);
                btn.setImageBitmap(b1);
            }




        }

//        byte[] img = extras.getString("user_image");

//        Bitmap b1 = BitmapFactory.decodeByteArray(extras.getString("user_image"), 0, img1.length);
//        iv.setImageBitmap(b1);

    }


    public void upload_profile_pic(View view){
        System.out.println("image upload selection");
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);

    }

    @Override
    public void onBackPressed(){
        this.startActivity(new Intent(this,MainActivity.class));
    }


}