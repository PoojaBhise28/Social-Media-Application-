package com.example.test;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class CaptureImage extends AppCompatActivity {
    TextView user_name, user_email, user_contact;
    public static final int PICK_IMAGE = 1;
    private Bitmap bitmap;
    DatabaseUtil dbUtil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capture_image);
        Bundle extras = getIntent().getExtras();
        user_name = (TextView) findViewById(R.id.name);
        user_email = (TextView) findViewById(R.id.email);
        user_contact = (TextView) findViewById(R.id.contact);
//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//
//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
    }

    public void submit(View view){
        EditText editText = (EditText)findViewById(R.id.myImageViewText);
        Bitmap bmp = Bitmap.createBitmap(editText.getDrawingCache());
//        Bitmap combined = combineImages(bgBitmap,bmp);
    }

    public Bitmap combineImages(Bitmap background, Bitmap foreground) {

        int width = 0, height = 0;
        Bitmap cs;

        width = getWindowManager().getDefaultDisplay().getWidth();
        height = getWindowManager().getDefaultDisplay().getHeight();

        cs = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas comboImage = new Canvas(cs);
        background = Bitmap.createScaledBitmap(background, width, height, true);
        comboImage.drawBitmap(background, 0, 0, null);
//        comboImage.drawBitmap(foreground, matrix, null);

        return cs;
    }
}