package com.example.test;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;


import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class DatabaseUtil extends SQLiteOpenHelper {


    public DatabaseUtil(Context context) {
        super(context, "testData.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table IF NOT EXISTS users(name Text, contact Text, email Text primary key, password Text, registered_date Date, profile_img Blob)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists users");
    }

    public Boolean insert_user_data(String name, String contact, String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("contact", contact);
        values.put("email", email);
        values.put("password", password);
        String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        values.put("registered_date", date);
        long result = db.insert("users", null, values);
        db.close();
        System.out.println("insrt result:::" + result);
        if(result==-1){
            return false;
        }
        else{
            return true;
        }

    }

//    public HashMap<String, String> login_user(String email, String password){
    public HashMap<String, Object> login_user(String email, String password){
        String user_name=null, user_email=null, user_contact=null;
        byte[] byteArray=null;
        SQLiteDatabase db = this.getWritableDatabase();
        GetterSetterUserProfile getProfileUser = null;
        Cursor cursor = db.rawQuery("Select name, email, contact, profile_img from users where email=? and password=?", new String[] {email, password});
        if(cursor.moveToFirst()){
             user_name = cursor.getString(0);
             user_email = cursor.getString(1);
             user_contact = cursor.getString(2);
             byteArray = cursor.getBlob(3);
             System.out.println("byteArray"+ byteArray);
             getProfileUser = new GetterSetterUserProfile(user_name, user_email, user_contact, byteArray);


        }
        cursor.close();
        db.close();
//        JSONObject jsonObj = new JSONObject();
//        jsonObj.put("name", user_name);
//        jsonObj.put("email", user_email);
//        jsonObj.put("contact", user_contact);
//        HashMap<String,String> map = new HashMap<String, String>();
//        map.put("name", user_name);
//        map.put("email", user_email);
//        map.put("contact", user_contact);

        HashMap<String,Object> map = new HashMap<String, Object>();
        map.put("user_data", getProfileUser);
        return map;



    }

    public Boolean update_profile(Bitmap bitmap, String user_id){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();

        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);

        byte[] byteArray = stream.toByteArray();
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("profile_img", byteArray);
        db.update("users", values, "email=?", new String[]{user_id});
//        values.put("contact", contact);
//        values.put("email", email);
//        values.put("password", password);
//        String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
//        values.put("registered_date", date);
//        long result = db.insert("users", null, values);
//        db.close();
//        System.out.println("insrt result:::" + result);
//        if(result==-1){
//            return false;
//        }
//        else{
            return true;
//        }
    }


    public HashMap<String, Object> get_user_profile_pic(String email){
        String user_name=null, user_email=null, user_contact=null;
        byte[] byteArray=null;
        SQLiteDatabase db = this.getWritableDatabase();
        GetterSetterUserProfile getProfileUser = null;
        Cursor cursor = db.rawQuery("Select name, email, contact, profile_img from users where email=? ", new String[] {email});
        if(cursor.moveToFirst()){
            user_name = cursor.getString(0);
            user_email = cursor.getString(1);
            user_contact = cursor.getString(2);
            byteArray = cursor.getBlob(3);
            System.out.println("byteArray"+ byteArray);
            getProfileUser = new GetterSetterUserProfile(user_name, user_email, user_contact, byteArray);


        }
        cursor.close();
        db.close();
//        JSONObject jsonObj = new JSONObject();
//        jsonObj.put("name", user_name);
//        jsonObj.put("email", user_email);
//        jsonObj.put("contact", user_contact);
//        HashMap<String,String> map = new HashMap<String, String>();
//        map.put("name", user_name);
//        map.put("email", user_email);
//        map.put("contact", user_contact);

        HashMap<String,Object> map = new HashMap<String, Object>();
        map.put("user_data", getProfileUser);
        return map;



    }

}
