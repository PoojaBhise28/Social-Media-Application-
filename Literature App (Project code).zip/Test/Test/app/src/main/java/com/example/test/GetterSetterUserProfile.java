package com.example.test;

import android.graphics.Bitmap;

public class GetterSetterUserProfile {
    String username = null;
    String email = null;
    String contact = null;
    byte[] data = null;
    public GetterSetterUserProfile(String username, String email, String contact, byte[] data){
        this.username = username;
        this.email = email;
        this.contact = contact;
        this.data = data;
    }

    public String getUser(){
        return this.username;
    }
    public String getEmail(){
        return this.email;
    }
    public String getContact(){
        return this.contact;
    }
    public byte[] getImage(){
        return this.data;
    }
//    public void setUser(String username){
//        return this.username;
//    }
//    public String getUser(){
//        return this.username;
//    }

}
