package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class Login extends AppCompatActivity {

    DatabaseUtil db;
    EditText user_id, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_login);

        SharedPreferences sp = getSharedPreferences("login", Context.MODE_PRIVATE);
        Boolean islogin = sp.getBoolean("islogin", false);
        System.out.println("isLogin::::"+ islogin);
        if(islogin==true){
            String user_name = sp.getString("name", null);
            String user_email = sp.getString("email", null);
            String user_contact = sp.getString("contact", null);
            System.out.println("username" + user_name+" email:"+user_email+" contact:::"+ user_contact+"   ====");
            Toast.makeText(this, "username" + user_name+" email:"+user_email+" contact:::"+ user_contact, Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, MainActivity.class) ;
            intent.putExtra("user_name", user_name);
            intent.putExtra("user_email", user_email);
            intent.putExtra("user_contact", user_contact);
            startActivity(intent);
        }

    }

    public void user_login(View view){
        user_id = findViewById(R.id.user_id);
        password = findViewById(R.id.password);
        db = new DatabaseUtil(this);

        HashMap<String,Object> user_data = db.login_user(user_id.getText().toString(), password.getText().toString());
        System.out.println("user_data:::"+ user_data.get("user_data"));

        if(user_data.get("user_data") == null){
            Toast.makeText(this, "Invalid", Toast.LENGTH_LONG).show();
            return ;
        }
        else{
            GetterSetterUserProfile userprofile = (GetterSetterUserProfile) user_data.get("user_data");
            String user_name = userprofile.getUser();
            String user_email = userprofile.getEmail();
            String user_contact = userprofile.getContact();
            byte[] user_image = userprofile.getImage();
            System.out.println(user_image+"  user_image");
            System.out.println("imageeeeee");

           Toast.makeText(this, "username" + user_name+" email:"+user_email+" contact:::"+ user_contact+"   user_image::"+user_image, Toast.LENGTH_LONG).show();
           Intent intent = new Intent(this, MainActivity.class) ;
           intent.putExtra("user_name", user_name);
           intent.putExtra("user_email", user_email);
           intent.putExtra("user_contact", user_contact);
           startActivity(intent);
        }


    }

    public void user_register(View view){

        Intent intent = new Intent(this, Register.class) ;
        startActivity(intent);
    }
}